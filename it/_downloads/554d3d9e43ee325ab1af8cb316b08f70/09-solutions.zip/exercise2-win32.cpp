#include <windows.h>
#include <stdlib.h>
#include <stdio.h>


constexpr auto BUFFER_SIZE = 1024;

/*
 * Win32 API Doc : Interlocked Variable Access (https://docs.microsoft.com/en-us/windows/win32/sync/interlocked-variable-access)
 * 
 * Simple reads and writes to properly aligned 64-bit variables are atomic on 64-bit Windows.
 * Reads and writes to 64-bit values are not guaranteed to be atomic on 32-bit Windows.
 * Reads and writes to variables of other sizes are not guaranteed to be atomic on any platform.
 * 
 * Otherwise, use InterlockedCompareExchangePointer.
 */
__declspec(align(64)) volatile char* buffer;


BOOL ctrl_break_handler(DWORD ctrl_type)
{
	char* tmp;

	if (ctrl_type == CTRL_BREAK_EVENT)
	{
		tmp = (char*)InterlockedExchangePointer((PVOID volatile*)&buffer, NULL);

		printf("\nStringa consumata: %s\n", tmp);

		free(tmp);

		return true;
	}

	return false;
}


int main(int argc, TCHAR* argv[])
{
	if (SetConsoleCtrlHandler((PHANDLER_ROUTINE)ctrl_break_handler, true) == 0)
		return -1;

	while (1)
	{
		if ((buffer = (char*)malloc(BUFFER_SIZE)) == NULL)
			return -1;

		printf("\nInserisci una nuova stringa: ");
		scanf_s("%[^\n]", buffer, BUFFER_SIZE);
		while (getchar() != '\n') ;

		GenerateConsoleCtrlEvent(CTRL_BREAK_EVENT, 0);

		while (buffer != NULL);
	}

	return 0;
}
