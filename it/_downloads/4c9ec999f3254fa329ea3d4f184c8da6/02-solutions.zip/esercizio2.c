#include <unistd.h>
#include <sys/wait.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

void main(int argc, char *argv[])
{
	pid_t pid;
	int status;
	char *text;
	int i,j;
	size_t len;
	printf("Enter any string: ");
	scanf("%m[^\n]", &text);
	len = strlen(text);
	int n = 2;
	n = n > len ? len : n;
	printf("taglia della stringa %lu %lu\n", len, sizeof(size_t));
	
	for(int i=0;i<n;i++){
		pid = fork();
		if (pid == -1) {
			printf("Unable to fork new process\n");
			exit(-1);
		}
		if (pid == 0) {
			for(int j=0;j<len/n + (i==0?len%n:0) ;j++)
				printf("%c", text[len-1-i*len/n-j-(i!=0?len%n:0)]);
			fflush(stdout);
			exit(0);
		} else {
			wait(&status);
		}
	}
	printf("\n");
	free(text);
}