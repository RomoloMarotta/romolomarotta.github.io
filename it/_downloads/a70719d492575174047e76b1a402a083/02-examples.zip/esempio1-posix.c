#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/wait.h>

int main(){
	int res, status;
	for(int i=0;i<2;i++){
		printf("I'm a process and I'm going to create a child #%d\n", i);
		res = fork();
		if(res < 0) printf("I cannot create a child #%d", i);
		else if(res == 0){
			sleep(5);
			if(i)printf("I'm the child #%d!\n", (*(int*)(NULL))); 
			else printf("I'm the child #%d!\n", i);
			exit(0xf);
		}
		else{
			printf("I'm now a parent and I'll wait for my child #%d to die...\n", i);
			wait(&status);
			if(WIFEXITED(status))
				printf("My child #%d has terminated normally and it invoked exit(%d)\n", i, WEXITSTATUS(status));
			else if(WIFSIGNALED(status))
				printf("My child #%d has terminated due to signal %d\n", i, WTERMSIG(status));
		}
		printf("My child #%d is dead, so it's my time to die\n", i);
	}
	exit(0);
}
