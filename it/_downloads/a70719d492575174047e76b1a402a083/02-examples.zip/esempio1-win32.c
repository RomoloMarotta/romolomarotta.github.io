#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main(int argc, char* argv[]){

	int res, status;
	for(int i=0;i<2;i++){

		// use argc to distinguish between parent and child
		if (argc != 1){
			sleep(5);
			i = atoi(argv[1]);
			if(i)printf("I'm the child #%d!\n", (*(int*)(NULL))); 
			else printf("I'm the child #%d!\n", i);
			ExitProcess(0xf);
		}
		else{
			printf("I'm a process and I'm going to create a child #%d\n", i);
			BOOL newprocess;
			STARTUPINFO si;
			PROCESS_INFORMATION pi;
			DWORD exitcode;
			char text[1024];
			memset(&si, 0, sizeof(si));
			memset(&pi, 0, sizeof(pi));
			si.cb = sizeof(si);
			sprintf(text, "%s %d", argv[0], i);

			newprocess = CreateProcess((LPCSTR)argv[0], (LPSTR)text, NULL, NULL, FALSE,
			NORMAL_PRIORITY_CLASS, NULL, NULL, (LPSTARTUPINFOA)&si, &pi);

			if (newprocess == FALSE) printf("I cannot create a child #%d", i);
			
			printf("I'm now a parent and I'll wait for my child #%d to die...\n", i);
			WaitForSingleObject(pi.hProcess, INFINITE);
			GetExitCodeProcess(pi.hProcess, &exitcode);
			if(IS_ERROR(exitcode))	printf("My child #%d has terminated with error code (%x)\n", i, HRESULT_CODE(exitcode));
			else 			printf("My child #%d has terminated normally and it invoked exit(%x)\n", i, HRESULT_CODE(exitcode));
			CloseHandle(pi.hThread);
			CloseHandle(pi.hProcess);
		}
	}
}
