#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#include <string.h>
#include <pthread.h>

void * server(void *arg)
{
	int fd;
	ssize_t bytes;
	int num = 0;

	char *fifonamec;
	char message[32];

	if ((fifonamec = (char *) arg) == NULL)
		pthread_exit((void *) -1);

	while (num < 10)
	{
		if (snprintf(message, 32, "%d", ++num) < 0)
		{
			free(fifonamec);
			pthread_exit((void *) -1);
		}

        printf("Server Thread: opening fifo for write...");
		fflush(stdout);

		if ((fd = open(fifonamec, O_WRONLY)) < 0)
		{
			free(fifonamec);
			pthread_exit((void *) -1);
		}
        
        
		printf("Done\nServer Thread: sending '%d' through %s...", num, fifonamec);
		fflush(stdout);
		if (write(fd, message, 32) < 0)
		{
			close(fd);
			free(fifonamec);
			pthread_exit((void *) -1);
		}

		printf("Done\n");
		close(fd);

        printf("Server Thread: opening fifo for read...");
		fflush(stdout);
		if ((fd = open(fifonamec, O_RDONLY)) < 0)
		{
			free(fifonamec);
			pthread_exit((void *) -1);
		}

  		printf("Done\nServer Thread: reading from %s...", fifonamec);
        fflush(stdout);

		while ((bytes = read(fd, message, 32)) == 0);

		close(fd);

		num = atoi(message);

		printf("Done\nServer Thread: got '%d' through %s\n", num, fifonamec);
	}

	free(fifonamec);
	pthread_exit((void *) 0);
}

int main(int argc, char *argv[])
{
	int fd;
	ssize_t bytes;
	pthread_t thread;

	char * arg;
	char fifonamec[32];

	const char *fifonames = "server_fifo";

	if (mkfifo(fifonames, S_IRUSR|S_IWUSR) && errno != EEXIST){
		printf("cannot create pipe\n");
		return -1;
	}
    
    printf("Server Main: opening fifo for read...");
    fflush(stdout);
	if ((fd = open(fifonames, O_RDONLY)) < 0)	return -1;
    printf("Done\n");
	while (1){
		while ((bytes = read(fd, fifonamec, 32)) == 0) sleep(1);

		if ((arg = strdup(fifonamec)) == NULL)
		{
			close(fd);
			return -1;
		}
		if (pthread_create(&thread, NULL, server, (void *) arg))
		{
			free(arg);
			close(fd);
			return -1;
		}
	}

	return 0;
}
