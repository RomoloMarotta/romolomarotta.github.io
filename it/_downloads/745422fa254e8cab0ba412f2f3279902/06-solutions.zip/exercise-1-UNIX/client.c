#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#include <string.h>
#include <pthread.h>

void * client(void *arg)
{
	int fd;
	ssize_t bytes;
	int num = 0;

	char fifonamec[32];
	char message[32];
    int id = *((int*) arg);
    
	if (snprintf(fifonamec, 32, "client_fifo_%d", id) < 0) pthread_exit((void *) -1);
    

	while (num < 10)
	{
        printf("Client Thread: opening fifo for reading...");
        fflush(stdout);
        sleep(5);
		if ((fd = open(fifonamec, O_RDONLY)) < 0)	pthread_exit((void *) -1);

        printf("Done\nClient Thread: reading...");
        fflush(stdout);
		while ((bytes = read(fd, message, 32)) == 0);

		close(fd);

		num = atoi(message);

		printf("Done\nClient Thread %d got: %d\n", id, num);

		if (snprintf(message, 32, "%d", ++num) < 0)		pthread_exit((void *) -1);

        printf("Client Thread: opening fifo for writing...");
        fflush(stdout);
        sleep(5);
		
        if ((fd = open(fifonamec, O_WRONLY)) < 0) pthread_exit((void *) -1);
		
        printf("Done\nClient Thread: writing...");
        fflush(stdout);
		if (write(fd, message, 32) < 0)
		{
			close(fd);
			pthread_exit((void *) -1);
		}
        printf("Done\n");

		close(fd);
	}

	pthread_exit((void *) 0);
}

int main(int argc, char *argv[])
{
	int i;
	int nt;
	int fd;
	int nthreads;
	char *arg;
	char fifonamec[32];
	const char *fifonames = "server_fifo";

	if (argc < 2) nt = 1;
	else if ((nt = atoi(argv[1])) < 1)	nt = 1;

	pthread_t threads[nt];
    int ids[nt];

    printf("Client Main: opening fifo for write...");
	fflush(stdout);
    if ((fd = open(fifonames, O_WRONLY)) < 0)
		return -1;
    printf("Done\n");
    
	for (i=0, nthreads=0; i<nt; i++)
	{
		if (snprintf(fifonamec, 32, "client_fifo_%d", nthreads) < 0)
			continue;

		while (mkfifo(fifonamec, S_IRUSR|S_IWUSR) && errno == EEXIST){
        	break;//unlink(fifonamec);
        }

        printf("Client Main: writing name of fifo...");
        fflush(stdout);
        
		if (write(fd, fifonamec, 32) < 0) continue;
        
        printf("Done\n");

		if ((arg = strdup(fifonamec)) == NULL)	continue;
        ids[i]=i;
		if (pthread_create(&threads[nthreads], NULL, client, (void *) (ids+i)) == 0)	nthreads++;
	}

	close(fd);

	for (i=0; i<nthreads; i++) 	pthread_join(threads[i], NULL);

	return 0;
}
