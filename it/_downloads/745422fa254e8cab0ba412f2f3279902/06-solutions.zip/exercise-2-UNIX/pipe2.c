#include <sys/types.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <stdio.h>
#include <time.h>

const char *filename = "writer_output.txt";

const char *granted_to_write = "WRITE";
const char *write_completed = "ACK";

int writer_function(int pipefd[][2][2], int id, int fd)
{
	int i;
	int nm;
	pid_t pid;
	ssize_t bytes;
	char message[128];
	char grant[strlen(granted_to_write)];

	for (i=0; i<id; i++)
	{
		close(pipefd[i][0][0]);
		close(pipefd[i][0][1]);
		close(pipefd[i][1][0]);
		close(pipefd[i][1][1]);
	}

	close(pipefd[id][0][1]);
	close(pipefd[id][1][0]);

	nm = 0;
	pid = getpid();

	while (1)
	{
		if ((bytes = read(pipefd[id][0][0], grant, strlen(granted_to_write))) == -1)
		{
			printf("Unable to read from Pipe of master process.\n");
			continue;
		}
		else if (bytes == 0)
		{
			break;
		}

		if (snprintf(message, 128, "This is the message number %d written by the writer %d\n", ++nm, id) > 0)
		{
			write(fd, message, strlen(message));
		}

		if (write(pipefd[id][1][1], write_completed, strlen(write_completed)) == -1)
		{
			printf("Unable to write on Pipe for master process.\n");
			continue;
		}
	}

	close(fd);

	close(pipefd[id][0][0]);
	close(pipefd[id][1][1]);

	return 0;
}

int server_function(int pipefd[][2][2], int nr)
{
	int i;
	int id;
	int number_of_grants;
	char ack[strlen(write_completed)];

	for (i=0; i<nr; i++)
	{
		close(pipefd[i][0][0]);
		close(pipefd[i][1][1]);
	}

	number_of_grants = nr * 10;
	srand((unsigned int) time(NULL));

	while (number_of_grants--)
	{
		id = rand() % nr;

		if (write(pipefd[id][0][1], granted_to_write, strlen(granted_to_write)) == -1)
		{
			printf("Unable to write on Pipe for writer %d.\n", id);
			continue;
		}

		if (read(pipefd[id][1][0], ack, strlen(write_completed)) == -1)
		{
			printf("Unable to read from Pipe of writer %d.\n", id);
			continue;
		}
	}

	for (i=0; i<nr; i++)
	{
		close(pipefd[i][1][0]);
		close(pipefd[i][0][1]);
	}

	return 0;
}

int main(int argc, char *argv[])
{
	int i;
	int fd;
	int res;
	pid_t pid;
	int status;
	int num_writers;

	if (argc < 2)
	{
		printf("Missing argument. Try again with:  <num_writers>\n");
		return -1;
	}

	if ((num_writers = atoi(argv[1])) < 1)
	{
		printf("Number of writers is a positive value greater than zero.\n");
		return -1;
	}

	if ((fd = open(filename, O_CREAT|O_WRONLY, S_IRUSR|S_IWUSR)) == -1)
	{
		printf("Unable to open file/create file %s.\n", filename);
		return -1;
	}

	int pipefd[num_writers][2][2];

	for (i=0; i<num_writers; i++)
	{
		if (pipe(pipefd[i][0]) == -1 || pipe(pipefd[i][1]) == -1)
		{
			printf("Unable to instanciate Pipe resources.\n");
		}

		if ((pid = fork()) == -1)
		{
			printf("Unable to fork child process.\n");
			return -1;
		}
		else if (pid == 0)
		{
			res = writer_function(pipefd , i, fd);
			return res;
		}
	}

	close(fd);

	res = server_function(pipefd, num_writers);

	for (i=0; i<num_writers; i++)
		wait(&status);

	return res;
}
