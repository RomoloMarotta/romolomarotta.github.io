#include <stdio.h>
#include <string.h>

int main(int argc, char *argv[])
{
	int i, j;
	char buff[21];

	if (argc != 2)
	{
		printf("Nessuna stringa passata come argomento. "
			"Utilizzo: <nome_prog> <stringa da invertire>\n");
		return 0;
	}

	// copio la stringa char by char
	for (i=0; i<20; i++)
	{
		if (argv[1][i] == '\0')
			break;
		buff[i] = argv[1][i];
	}
	buff[i] = '\0';

	printf("%s\n", buff);

	// inversione in place della stringa senza ricorrere 
	// a buffer e/o variabili temporanee
	for (j=0; j<(i/2); j++)
	{
		buff[i-j-1] = buff[i-j-1] ^ buff[j]; 
		buff[j] = buff[j] ^ buff[i-j-1];  
		buff[i-j-1] = buff[i-j-1] ^ buff[j];
	}

	printf("%s\n", buff);
}