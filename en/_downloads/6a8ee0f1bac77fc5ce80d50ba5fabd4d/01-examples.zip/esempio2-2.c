#include <stdio.h>

#define BUG 0
#define RES_CHECK 1

int main()
{
    char buff[1024];
    for(int i=0;i<1024;i++)buff[i]='z';
    int res = 0;
    while (1)
    {
        res = scanf("%[^\n]", buff); // salva in buf la stringa escluso il carattere '\n'
      #if RES_CHECK == 1
        // digitando invio senza precederlo da alcun carattere, il contenuto di buff viene 
        // stampato a schermo
        if(!res) buff[0] = 0; // impostando come primo carattere '\0' in questo scenario
        // la printf seguente stampa una stringa vuota 
      #endif
        printf("res:%d buff:'%s'\n", res, buff);
      #if BUG == 0
        // il carattere '\n' non viene consumato dalla libreria che legge stringa vuota
        getchar(); // tramite la funzione getchar viene consumato esattamente un carattere
      #endif
    }

    return 0;
}