#include <stdio.h>

int main()
{
    char buff[1024];
    int res = 0;
    for(int i=0;i<1024;i++)buff[i]='z';
    while (1)
    {
        res = scanf("%s", buff);
        printf("res:%d buff:'%s'\n", res, buff);
    }

    return 0;
}