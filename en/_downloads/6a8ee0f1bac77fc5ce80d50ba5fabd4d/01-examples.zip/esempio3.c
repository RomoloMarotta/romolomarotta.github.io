#include <stdio.h>
#include <stdlib.h>

int main()
{
    char buff[1024];
    for(int i=0;i<1024;i++)buff[i]='z';

    // l'utilizzo di '*' permette di indicare ala scanf
    // che il primo specificatore non è di interesse
    scanf("%*s %3c", buff);           // il '3' tra '%' e 'c' richiedere alla scanf di leggere esattamente 3 caratteri
    printf("input 1: '%s'\n", buff);
    // il '10' tra '%' e 's' richiedere alla scanf una stringa non vuota di al più 10 caratteri
    scanf("%10s", buff);
    printf("input 2: '%s'\n", buff);
    return 0;
}