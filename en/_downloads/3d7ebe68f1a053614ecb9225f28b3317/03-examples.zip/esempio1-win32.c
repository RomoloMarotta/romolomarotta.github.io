#include <windows.h>
#include <stdio.h>


DWORD WINAPI child_func(LPVOID lpParam)
{
	INT i = *(INT*)lpParam;
	sleep(2);
    printf("I'm the child #"); fflush(stdout);
    if(i)printf("%d!\n", (*(int*)(NULL))); 
    else printf("%d!\n", i);
	ExitThread(0xf);
}

int main()
{
	UINT i;
	DWORD hId;
	HANDLE hThread;
    DWORD status;
    for(int i=0;i<2;i++){
        printf("I'm a thread and I'm going to create a child #%d\n", i);
        hThread = CreateThread(NULL, 0,  (LPTHREAD_START_ROUTINE)child_func, (LPVOID) &i, 0, &hId);
        if(hThread == FALSE){
            printf("Unable to create a new thread with code %lu.\n", GetLastError());
            ExitProcess(1);
        }
        printf("I'm now a parent and I'll wait for my child #%d to die...\n", i);
        WaitForSingleObject(hThread, INFINITE);
        GetExitCodeThread(hThread, &status);
        printf("My child #%d has terminated and it invoked ExitThread(%d)\n", i, status);
    }

	ExitProcess(0);
}
