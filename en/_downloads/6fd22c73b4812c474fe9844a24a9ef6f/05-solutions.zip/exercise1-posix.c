#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>

#define abort(msg) do{printf(msg);exit(1);}while(0)

#define BUF_SIZE 1000

int main(int argc, char *argv[]) {
    int ifd, ofd, size_r, size_w, end = 0; 
    int i = 0;
    if(argc != 3){
        printf("wrong number of parameters. Usage: command <num_shorts> <filename>\n");
        exit(1);
    }
    size_t filesize = atol(argv[1])*sizeof(short);

    char *data = malloc(BUF_SIZE*sizeof(short));
    /* open the input file and check errors */
    ifd=open("/dev/urandom",O_RDONLY);
    if (ifd == -1) abort("input open error\n");
    
    /* opend output file and check errors */
    ofd=open(argv[2],O_WRONLY|O_CREAT|O_TRUNC,0660); 
    if (ofd == -1) abort("output creation error\n");

    while(filesize != 0){
        int chucksize = BUF_SIZE;
        chucksize ^= (filesize^chucksize) & (-(filesize < chucksize));
 
        /* read up to BUFSIZE from input file and check errors */
        size_r=read(ifd,data,chucksize);
        if (size_r == -1) abort("read error\n"); 

        size_w = write(ofd,data,size_r);             
        if (size_w == -1) abort("write error\n");
        printf("written: %d\n", size_w);
        filesize -= size_w;
    }

    close(ifd);
    close(ofd);
}


