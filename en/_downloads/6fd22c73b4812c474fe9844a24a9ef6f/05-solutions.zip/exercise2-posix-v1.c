#define _GNU_SOURCE 
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include <fcntl.h>
#include <sys/sysinfo.h>

#define abort(msg) do{printf(msg);exit(1);}while(0)

#define MEM_PER_CORE (256*sizeof(short))
#define FILENAME "dataset.bin"

int ifd = 0;
ssize_t filesize;

void *process_func(void *param){
  int id = *((int*)param);
  cpu_set_t cpus;
  CPU_ZERO(&cpus);
  CPU_SET(id, &cpus);
  if (pthread_setaffinity_np(pthread_self(), sizeof(cpu_set_t), &cpus))
    printf("Warning. Unable to set thread affinity.\n");

  int chunk_size = filesize/get_nprocs();
  int offset = chunk_size*id;
  short *local_data = malloc(MEM_PER_CORE); 
  int i = 0,num_shorts=MEM_PER_CORE/sizeof(short);
  short min = 0x7fff, max=0x8000;
  size_t size_r = 0;
  size_t r = 0;
  while(1){
    r=read(ifd,local_data,MEM_PER_CORE);
    if(!r)break;
    size_r+=r;
    for(i=0;i<num_shorts;i++){
      if(min > local_data[i]) min = local_data[i];
      if(max < local_data[i]) max = local_data[i];
    }
  }
  short *res = (short*)param;
  res[0] = min;
  res[1] = max;
  printf("I am %d with fd %d and offset %d, read MB %ld, min %d, max %d\n", id, ifd, offset, size_r/1024/1024, min, max);
  close(ifd);
  return NULL;
}

int main() {
  int i = 0;
  int cores = get_nprocs();
  pthread_t tids[cores];
  int offset[cores];
  short *res = (short*) offset;
  short min = 0x7fff, max=0x8000;
  ifd = open(FILENAME,O_RDONLY);
  ssize_t filesize = lseek(ifd, 0, SEEK_END);
  lseek(ifd, 0, SEEK_SET);
  printf("%d %d %d %ld\n", min, max, ifd, filesize);
  for(i = 0;i<cores;i++){
    offset[i] = i;
    pthread_create(tids+i, NULL, process_func, offset+i);
  }
  for(i = 0;i<cores;i++){
    pthread_join(tids[i],NULL);
    if(min > res[2*i])   min = res[2*i];
    if(max < res[2*i+1]) max = res[2*i+1];
  }
  printf("Final min: %d max: %d\n", min, max);
}
