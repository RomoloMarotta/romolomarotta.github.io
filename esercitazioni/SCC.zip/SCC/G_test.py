from graph import Graph

g = Graph()

build_parameters = [('a','b'), ('a','d'), ('b','c'), ('c','d'), ('c','e'), ('d','e'), ('d','b')]

print("Graph 1 building...", end = '')
for u,v in build_parameters:
	g.insertEdge(u,v)
g.insertNode('f')
print("Done")

g.plot("g1")


res = g.getConnectedComponents()
checker =   g.getConnectedComponentsChecker()

print("Checking test 1...  : "+str(len(res))+" SCC found")
if not res-checker:
	print("OK")
else:
	print("FAIL")
print("")


print("Graph 2 building...", end = '')
g = Graph(20, 10, 131)
print("Done")
g.plot("g2")


res = g.getConnectedComponents()
checker =   g.getConnectedComponentsChecker()
print("Checking test 2...  : "+str(len(res))+" SCC found")
if not res-checker:
	print("OK")
else:
	print("FAIL")
print("")


print("Graph 3 building...", end = '')
g = Graph(50, 40, 137)
print("Done")

g.plot("g3")

res = g.getConnectedComponents()
checker =   g.getConnectedComponentsChecker()

print("Checking test 3...  : "+str(len(res))+" SCC found")
if not res-checker:
	print("OK")
else:
	print("FAIL")
print("")


print("Graph 4 building...", end = '')
g = Graph(90, 70, 1237)
print("Done")
g.plot("g4")


res = g.getConnectedComponents()
checker =   g.getConnectedComponentsChecker()

print("Checking test 4...  : "+str(len(res))+" SCC found")
if not res-checker:
	print("OK")
else:
	print("FAIL")
print("")

