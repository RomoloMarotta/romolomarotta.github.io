try:
	import networkx as nx
	nxf = True
except:
	nxf = False
import matplotlib
import matplotlib.pyplot as plt

import random
from random import seed
from random import random
from random import randint


class Graph:

	def vertices(self):
		return self._nodes.keys()

	def __len__(self):
		return len(self._nodes)

	def adj(self,u):
		if u in self._nodes:
			return self._nodes[u]

	def insertNode(self,u):
		if u not in self._nodes:
			self._nodes[u]={}
			if nfx: self._G.add_node(u) #shadow copy

	def insertEdge(self,u,v,w=0):
		self.insertNode(u)
		self.insertNode(v)
		self._nodes[u][v]=w
		if nfx: self._G.add_edge(u,v) #shadow copy


	def buildRandomGraph(self, nodes=0, edges=0, seedI=0):
		seed(seedI)
		for i in range(nodes):
			self.insertNode(i)

		for i in range(edges):
			u = randint(0,nodes-1)
			v = randint(0,nodes-1)
			self.insertEdge(u,v)


		start = 0
		end = 0
		l = 0
		for k in range(nodes*2):
			r = random()
			if r < 0.15:
				l+=1
			else:
				if l > 0:
					for i in range(l):
						self.insertEdge((start+i)%nodes,(start+i+1)%nodes)
					self.insertEdge((start+i+1)%nodes, (start)%nodes)
					start+=l
				else:
					start = k%nodes
				l=0

	def __init__(self, nodes=0, edges=0, seedI=0):
		if nxf: self._G = nx.DiGraph(directed=True) #shadow copy
		self._nodes={}
		self._enter_times = {}
		self._cc = 0
		self._visited = set([])
	
		if nodes == 0:
			return

	def getConnectedComponentsChecker(self):
		res = set([])
		if nfx: return set(res)
		for l in nx.strongly_connected_components(self._G):
			res.add(frozenset(l))
		return set(res)

	def plot(self, name):
		if not nxf: return
		print("Plotting Graph "+name+"...", end = '')
		plt.switch_backend('agg')
		nx.draw(self._G, arrows=True, with_labels = True)
		plt.savefig(name+".png")
		print("Done")


	def getConnectedComponents(self):
		#TODO!!!!
		res = set([])
		res.add(frozenset(['a']))
		res.add(frozenset(['e']))
		res.add(frozenset(['f']))
		res.add(frozenset(['b','c','d']))
		return res
